﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Reflection;
using System.IO;

namespace PhantomJsTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string chromeDriverDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\\ChromeDriver";

            ChromeOptions options = new ChromeOptions();
            options.AddArguments("--proxy-server=socks5://127.0.0.1:9150");

            IWebDriver driver = new ChromeDriver(chromeDriverDir, options);

            //Navigate to google page
            driver.Navigate().GoToUrl("http://ipleak.com");

        }

        static bool linkIsValid(string link)
        {
            if (link != null
                && !link.ToLower().Contains(".google.")
                && !link.ToLower().Contains("javascript:")
                && !link.ToLower().Contains(".googleusercontent.")
                )
                return true;
            else
                return false;
        }
    }
}
