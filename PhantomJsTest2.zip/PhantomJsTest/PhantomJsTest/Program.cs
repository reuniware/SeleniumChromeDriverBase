﻿using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;

namespace PhantomJsTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string chromeDriverDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\\ChromeDriver";

            //Create the reference for our browser
            IWebDriver driver = new ChromeDriver(chromeDriverDir);

            //Navigate to google page
            driver.Navigate().GoToUrl("https://www.google.com");
            By locator = By.Name("q");
            IWebElement element = driver.FindElement(locator);
            element.SendKeys("forex");
            element.Submit();

            List<string> lstLink = new List<string>();
            locator = By.TagName("a");
            IReadOnlyCollection<IWebElement> elements = driver.FindElements(locator);
            foreach (IWebElement elem in elements)
            {
                string link = elem.GetAttribute("href");
                if (linkIsValid(link))
                {
                    Console.WriteLine(link);
                    lstLink.Add(link);
                }
            }

            List<IWebElement> lstPageElem = new List<IWebElement>();
            locator = By.TagName("a");
            IReadOnlyCollection<IWebElement> elementsPage = driver.FindElements(locator);
            foreach (IWebElement elem in elements)
            {
                if (elem.GetAttribute("aria-label") != null && elem.GetAttribute("aria-label").ToLower().Contains("page "))
                {
                    Console.WriteLine(elem.GetAttribute("aria-label"));
                    lstPageElem.Add(elem);
                }
            }

            lstPageElem[0].Click();
        }

        static bool linkIsValid(string link)
        {
            if (link != null
                && !link.ToLower().Contains(".google.")
                && !link.ToLower().Contains("javascript:")
                && !link.ToLower().Contains(".googleusercontent.")
                )
                return true;
            else
                return false;
        }
    }
}
